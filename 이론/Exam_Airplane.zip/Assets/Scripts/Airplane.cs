using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Airplane: MonoBehaviour
{
    public float rotateSpeed = 720.0f;
    public float moveSpeed = 5.0f;

    Transform[] waypoints;
    Transform propeller;
    int targetIndex = 0;

    private void Awake()
    {
        waypoints = new Transform[2];
        waypoints[0] = GameObject.Find("Waypoint1").transform;
        waypoints[1] = GameObject.Find("Waypoint2").transform;

        //propeller = transform.Find("Propeller");
        propeller = transform.GetChild(4);
    }

    private void Start()
    {
        transform.LookAt(waypoints[targetIndex]);
    }

    private void Update()
    {
        Vector3 dir = waypoints[targetIndex].position - transform.position;
        transform.Translate(moveSpeed * Time.deltaTime * dir.normalized, Space.World);
        propeller.Rotate(0, 0, rotateSpeed * Time.deltaTime);
        if(dir.sqrMagnitude < 0.0025f )
        {
            GoNextWaypoint();
        }
    }

    void GoNextWaypoint()
    {
        targetIndex++;
        targetIndex %= waypoints.Length;
        transform.LookAt(waypoints[targetIndex]);
    }

}
